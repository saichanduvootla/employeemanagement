package net.javaguides.springboot;

public class SaveEmployee {
	 @Test
	    @Order(1)
	    @Rollback(value = false)
	    public void saveEmployeeTest(){

	        Employee employee = Employee.builder()
	                .firstName("Ramesh")
	                .lastName("Fadatare")
	                .email("ramesh@gmail.com")
	                .build();

	        employeeRepository.save(employee);

	        Assertions.assertThat(employee.getId()).isGreaterThan(0);
	    }
}
